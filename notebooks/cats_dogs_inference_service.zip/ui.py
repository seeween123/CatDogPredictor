import os

import gradio as gr
import requests

API_URL = os.getenv("API_URL", "http://127.0.0.1:8000")


def check_health():
    try:
        response = requests.get(f"{API_URL}/health", timeout=10)
        response.raise_for_status()
        data = response.json()
        return f"API Status: {data['status']}\nModel loaded: {data['model_loaded']}"
    except Exception as exc:
        return f"API unavailable: {exc}"


def predict(image):
    if image is None:
        return "Please upload an image.", None

    try:
        # Gradio supplies a NumPy array when type='numpy'.
        from PIL import Image
        import io

        pil_image = Image.fromarray(image.astype("uint8"))
        buffer = io.BytesIO()
        pil_image.save(buffer, format="PNG")
        buffer.seek(0)

        response = requests.post(
            f"{API_URL}/predict",
            files={"file": ("image.png", buffer, "image/png")},
            timeout=60,
        )
        response.raise_for_status()
        data = response.json()

        result = (
            f"Prediction: {data['label']}\n"
            f"Confidence: {data['confidence'] * 100:.2f}%\n\n"
            f"Cat: {data['probabilities']['Cat'] * 100:.2f}%\n"
            f"Dog: {data['probabilities']['Dog'] * 100:.2f}%"
        )

        return result, data["probabilities"]

    except requests.RequestException as exc:
        return f"Prediction API error: {exc}", None
    except Exception as exc:
        return f"Error: {exc}", None


with gr.Blocks(title="Cats vs Dogs Classifier") as demo:
    gr.Markdown(
        """
        # 🐱🐶 Cats vs Dogs Classifier

        Upload an image and the application will call the **FastAPI
        inference service** to classify it as Cat or Dog.
        """
    )

    health_output = gr.Textbox(
        label="API Health",
        value="Click 'Check API Health' to test the service.",
    )

    health_button = gr.Button("Check API Health")

    with gr.Row():
        with gr.Column():
            image_input = gr.Image(
                type="numpy",
                label="Upload Cat/Dog Image",
            )
            predict_button = gr.Button("Predict", variant="primary")

        with gr.Column():
            prediction_output = gr.Textbox(
                label="Prediction",
                lines=5,
            )
            probability_output = gr.Label(
                label="Class Probabilities",
            )

    health_button.click(
        fn=check_health,
        inputs=None,
        outputs=health_output,
    )

    predict_button.click(
        fn=predict,
        inputs=image_input,
        outputs=[prediction_output, probability_output],
    )

if __name__ == "__main__":
    demo.launch()
